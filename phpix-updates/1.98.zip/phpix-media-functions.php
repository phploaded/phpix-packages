<?php

if(!function_exists('phpix_is_webp_quality')){
function phpix_is_webp_quality($quality){
	return in_array($quality, array('2k', 'fhd', 'hd'), true);
}
}

if(!function_exists('phpix_quality_dimension')){
function phpix_quality_dimension($quality){
	$quality_index = array(
	"2k" => 1440,
	"fhd" => 1080,
	"hd" => 720,
	);

	if(isset($quality_index[$quality])){
		return $quality_index[$quality];
	}

	return 0;
}
}

if(!function_exists('phpix_allowed_media_qualities')){
function phpix_allowed_media_qualities(){
	return array('full', '2k', 'fhd', 'hd', 'thumb', 'cover');
}
}

if(!function_exists('phpix_is_allowed_media_quality')){
function phpix_is_allowed_media_quality($quality, $allowed_qualities = null){
	$quality = strtolower(trim((string) $quality));
	if($allowed_qualities === null){
		$allowed_qualities = phpix_allowed_media_qualities();
	}

	return in_array($quality, $allowed_qualities, true);
}
}

if(!function_exists('phpix_normalize_media_quality')){
function phpix_normalize_media_quality($quality, $fallback = 'full'){
	$quality = strtolower(trim((string) $quality));
	if($quality == ''){
		return $fallback;
	}

	return $quality;
}
}

if(!function_exists('phpix_is_safe_media_file')){
function phpix_is_safe_media_file($file){
	$file = rawurldecode((string) $file);
	$file = trim(str_replace("\0", '', $file));
	if($file == ''){
		return false;
	}

	$normalized = str_replace('\\', '/', $file);
	return $file === basename($normalized);
}
}

if(!function_exists('phpix_normalize_media_file')){
function phpix_normalize_media_file($file){
	$file = rawurldecode((string) $file);
	$file = trim(str_replace("\0", '', $file));
	if($file == ''){
		return '';
	}

	$normalized = str_replace('\\', '/', $file);
	return basename($normalized);
}
}

if(!function_exists('phpix_media_filename')){
function phpix_media_filename($file, $quality = 'full'){
	$file_info = pathinfo($file);

	if(phpix_is_webp_quality($quality)){
		return $file_info['filename'].'.webp';
	}

	return $file_info['basename'];
}
}

if(!function_exists('phpix_media_relative_path')){
function phpix_media_relative_path($quality, $file){
	return $quality.'/'.phpix_media_filename($file, $quality);
}
}

if(!function_exists('phpix_media_disk_path')){
function phpix_media_disk_path($quality, $file){
	return dirname(__FILE__).'/'.phpix_media_relative_path($quality, $file);
}
}

if(!function_exists('phpix_legacy_media_disk_path')){
function phpix_legacy_media_disk_path($quality, $file){
	return dirname(__FILE__).'/'.$quality.'/'.pathinfo($file, PATHINFO_BASENAME);
}
}

if(!function_exists('phpix_media_url')){
function phpix_media_url($quality, $file){
	global $gallery_domain;
	return $gallery_domain.phpix_media_relative_path($quality, $file);
}
}

if(!function_exists('phpix_source_disk_path')){
function phpix_source_disk_path($file){
	return dirname(__FILE__).'/full/'.phpix_normalize_media_file($file);
}
}

if(!function_exists('phpix_open_image_resource')){
function phpix_open_image_resource($file, $image_type = null){
	if($image_type === null){
		$info = @getimagesize($file);
		if(!$info){
			return false;
		}
		$image_type = $info[2];
	}

	if($image_type == IMAGETYPE_JPEG){
		return @imagecreatefromjpeg($file);
	}

	if($image_type == IMAGETYPE_PNG){
		return @imagecreatefrompng($file);
	}

	if($image_type == IMAGETYPE_GIF){
		return @imagecreatefromgif($file);
	}

	if($image_type == IMAGETYPE_WEBP && function_exists('imagecreatefromwebp')){
		return @imagecreatefromwebp($file);
	}

	return false;
}
}

if(!function_exists('phpix_generate_webp_variant')){
function phpix_generate_webp_variant($source_file, $target_file, $quality, $compression = 80){
	if(!function_exists('imagewebp') || !file_exists($source_file)){
		return false;
	}

	$dimension = phpix_quality_dimension($quality);
	if($dimension < 1){
		return false;
	}

	$target_dir = dirname($target_file);
	if(!is_dir($target_dir)){
		mkdir($target_dir, 0777, true);
	}
	if(!file_exists($target_dir.'/index.html')){
		file_put_contents($target_dir.'/index.html', '');
	}

	$info = @getimagesize($source_file);
	if(!$info){
		return false;
	}

	$source = phpix_open_image_resource($source_file, $info[2]);
	if(!$source){
		return false;
	}

	$src_width = $info[0];
	$src_height = $info[1];

	if($src_width > $src_height){
		$target_height = min($dimension, $src_height);
		$scale = $target_height / $src_height;
		$target_width = max(1, (int) round($src_width * $scale));
	} else {
		$target_width = min($dimension, $src_width);
		$scale = $target_width / $src_width;
		$target_height = max(1, (int) round($src_height * $scale));
	}

	$canvas = imagecreatetruecolor($target_width, $target_height);
	imagealphablending($canvas, false);
	imagesavealpha($canvas, true);
	$transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
	imagefilledrectangle($canvas, 0, 0, $target_width, $target_height, $transparent);

	imagecopyresampled($canvas, $source, 0, 0, 0, 0, $target_width, $target_height, $src_width, $src_height);
	$result = imagewebp($canvas, $target_file, $compression);

	imagedestroy($canvas);
	imagedestroy($source);

	$legacy_file = phpix_legacy_media_disk_path($quality, basename($source_file));
	if($legacy_file !== $target_file && file_exists($legacy_file)){
		unlink($legacy_file);
	}

	return $result;
}
}

if(!function_exists('phpix_prepare_media_file')){
function phpix_prepare_media_file($quality, $file, $compression = 80){
	$quality = phpix_normalize_media_quality($quality);
	$file = phpix_normalize_media_file($file);
	if($file == ''){
		return false;
	}

	$source_file = phpix_source_disk_path($file);
	if(!file_exists($source_file)){
		return false;
	}

	if($quality == 'full'){
		return true;
	}

	if(!phpix_is_webp_quality($quality)){
		return false;
	}

	$target_file = phpix_media_disk_path($quality, $file);
	if(file_exists($target_file)){
		return true;
	}

	return phpix_generate_webp_variant($source_file, $target_file, $quality, $compression);
}
}

if(!function_exists('phpix_delete_generated_versions')){
function phpix_delete_generated_versions($file){
	foreach(array('2k', 'fhd', 'hd') as $quality){
		$target = phpix_media_disk_path($quality, $file);
		if(file_exists($target)){
			unlink($target);
		}

		$legacy_file = phpix_legacy_media_disk_path($quality, $file);
		if($legacy_file !== $target && file_exists($legacy_file)){
			unlink($legacy_file);
		}
	}
}
}
