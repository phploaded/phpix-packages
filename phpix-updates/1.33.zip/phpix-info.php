<?php 

$software_version = '1.33';
$software_date = '1599748208';
$software_updated = '1602235793';
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://github.com/phploaded/phpix-packages/raw/main/phpix-updates/';

 ?>