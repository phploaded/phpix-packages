<?php 
include('phpix-config.php');

$data = mysqli_fetch_assoc(mysqli_query($con, "SELECT `folder` FROM `".$prefix."uploads` WHERE `url`='".$_GET['pic']."' limit 1"));

$type = $_GET['type'];
$quality = $_GET['q'];

$url = $gallery_domain.''.$quality.'/'.$_GET['pic'];

$thumb = $gallery_domain.'qhd/'.$_GET['pic'];

echo'<!DOCTYPE html><html>
<head><meta property="og:title" content="'.$_GET['pic'].'" />
<meta property="og:url" content="'.$url.'" />
<meta property="og:description" content="'.$_GET['pic'].'">
<meta property="og:image" content="'.$thumb.'">
</head><body>
<script>document.location.href="'.$gallery_domain.'phpix-album.php?aid='.$data['folder'].'&q='.$quality.'&pic='.$_GET['pic'].'";</script>
</body>
';

?>