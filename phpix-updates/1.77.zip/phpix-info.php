<?php 

$software_version = '1.77';
$software_date = '1603041199'; /* Sunday, 18-10-2020, 07:13:19 pm */
$software_updated = '1731229400'; /* Sunday, 10-11-2024, 10:03:20 am */
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

?>