<?php 

$software_version = '2.07';
$software_date = '1603041199'; /* Sunday, 18-10-2020, 07:13:19 pm */
$software_updated = '1779288254'; /* Wednesday, 20-05-2026, 04:44:14 pm */
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

?>