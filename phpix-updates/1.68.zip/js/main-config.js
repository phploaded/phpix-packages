
var gal_vars_tags = 'show';
var gal_vars_mini_thumbs = 'hide';
var gal_vars_bgmode = 'static'; 

var gal_vars_themes = ["air","dark","light","pink"];
var gal_vars_theme = 'pink';

var gal_slide_animations = ["any-random","book","cubein","cubeout","movexyz","movez","oval","ovalbg","plain","shiftin","shiftout","spinx","spiny","spinz","tiltin","tiltout","wheel","zoomin","zoomout"];
var gal_slide_animation = 'any-random'; 

var gal_vars_button_set = 'flat-dark';
var gal_vars_button_sets = ["flat-color","flat-dark","flat-light"];
