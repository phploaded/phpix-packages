<?php 

$default_admin_theme = 'yeti.bootstrap.min';
$default_admin_menu = 'inverse';

$mlib_upload_resolution = '8k';

 ?>