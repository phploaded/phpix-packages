<?php

if (!function_exists('ai_pics_upload_scope_sql')) {
function ai_pics_upload_scope_sql($alias = 'u')
{
$adminSession = $_SESSION['PHPix'] ?? '';
$userSession = $_SESSION['phpixuser'] ?? '';

if ($adminSession != '') {
return array('sql' => '', 'types' => '', 'values' => array());
}

if ($userSession != '') {
return array(
'sql' => " WHERE `".$alias."`.`uid` = ?",
'types' => 's',
'values' => array($userSession),
);
}

return array('sql' => " WHERE 1 = 0", 'types' => '', 'values' => array());
}
}

if (!function_exists('ai_pics_upload_image_mime')) {
function ai_pics_upload_image_mime($tmpPath, $originalName)
{
$ext = strtolower(pathinfo((string) $originalName, PATHINFO_EXTENSION));
if (!in_array($ext, array('jpg', 'jpeg', 'png', 'webp'), true)) {
return '';
}

$imageInfo = @getimagesize($tmpPath);
if (!$imageInfo || !isset($imageInfo['mime'])) {
return '';
}

$mime = strtolower((string) $imageInfo['mime']);
if (!in_array($mime, array('image/jpeg', 'image/png', 'image/webp'), true)) {
return '';
}

return $mime;
}
}

if (!function_exists('ai_pics_create_image_resource')) {
function ai_pics_create_image_resource($tmpPath, $mime)
{
if ($mime === 'image/jpeg') {
return @imagecreatefromjpeg($tmpPath);
}
if ($mime === 'image/png') {
return @imagecreatefrompng($tmpPath);
}
if ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) {
return @imagecreatefromwebp($tmpPath);
}
return false;
}
}

if (!function_exists('ai_pics_convert_upload_to_webp')) {
function ai_pics_convert_upload_to_webp($tmpPath, $targetPath, $mime, $quality = 90)
{
$image = ai_pics_create_image_resource($tmpPath, $mime);
if (!$image) {
return false;
}

if (function_exists('imagepalettetotruecolor') && !imageistruecolor($image)) {
imagepalettetotruecolor($image);
}
imagealphablending($image, true);
imagesavealpha($image, true);

$saved = function_exists('imagewebp') ? @imagewebp($image, $targetPath, $quality) : false;
imagedestroy($image);
return $saved;
}
}

if (!function_exists('ai_pics_target_filename')) {
function ai_pics_target_filename($sourceFilename)
{
$sourceFilename = phpix_normalize_media_file($sourceFilename);
return pathinfo($sourceFilename, PATHINFO_FILENAME).'.webp';
}
}

if (!function_exists('ai_pics_target_disk_path')) {
function ai_pics_target_disk_path($sourceFilename)
{
return dirname(__FILE__).'/../ai/'.ai_pics_target_filename($sourceFilename);
}
}

$aiPicsDir = dirname(__FILE__).'/../ai';

if (!is_dir($aiPicsDir)) {
mkdir($aiPicsDir);
}
if (!file_exists($aiPicsDir.'/index.html')) {
file_put_contents($aiPicsDir.'/index.html', '');
}

if (!isset($notify['ai-pics'])) {
$notify['ai-pics'] = '';
}

$albumId = trim((string) ($_GET['aid'] ?? $_POST['aid'] ?? ''));
$scope = ai_pics_upload_scope_sql('a');
$albumSql = "SELECT `a`.`id`, `a`.`title`, `a`.`descr` FROM `".$prefix."albums` `a`".$scope['sql']." AND `a`.`id` = ? LIMIT 1";
if ($scope['sql'] === '') {
$albumSql = "SELECT `a`.`id`, `a`.`title`, `a`.`descr` FROM `".$prefix."albums` `a` WHERE `a`.`id` = ? LIMIT 1";
}

$albumRow = null;
if ($albumId !== '') {
$albumStmt = $con->prepare($albumSql);
if ($albumStmt) {
$types = $scope['types'].'s';
$values = $scope['values'];
$values[] = $albumId;
$bind = array($types);
foreach ($values as $key => $value) {
$bind[] = &$values[$key];
}
call_user_func_array(array($albumStmt, 'bind_param'), $bind);
$albumStmt->execute();
$albumResult = $albumStmt->get_result();
$albumRow = $albumResult ? $albumResult->fetch_assoc() : null;
if ($albumResult instanceof mysqli_result) {
$albumResult->free();
}
$albumStmt->close();
}
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['ai_upload_submit'])) {
$uploadId = trim((string) ($_POST['upload_id'] ?? ''));

if ($albumId === '' || !is_array($albumRow) || empty($albumRow['id'])) {
notify('Please open AI Pics from a valid album first.', 'ai-pics', 'warning');
} elseif ($uploadId === '') {
notify('No image was selected for AI upload.', 'ai-pics', 'warning');
} elseif (!isset($_FILES['ai_upload_file']) || !is_array($_FILES['ai_upload_file'])) {
notify('Please choose a JPG, JPEG, PNG, or WebP image to upload.', 'ai-pics', 'warning');
} else {
$scope = ai_pics_upload_scope_sql('u');
$sql = "SELECT `u`.`id`, `u`.`url` FROM `".$prefix."uploads` `u`".$scope['sql']." AND `u`.`folder` = ? AND `u`.`id` = ? LIMIT 1";
if ($scope['sql'] === '') {
$sql = "SELECT `u`.`id`, `u`.`url` FROM `".$prefix."uploads` `u` WHERE `u`.`folder` = ? AND `u`.`id` = ? LIMIT 1";
}

$stmt = $con->prepare($sql);
if ($stmt) {
$types = $scope['types'].'ss';
$values = $scope['values'];
$values[] = $albumId;
$values[] = $uploadId;
$bind = array($types);
foreach ($values as $key => $value) {
$bind[] = &$values[$key];
}
call_user_func_array(array($stmt, 'bind_param'), $bind);
$stmt->execute();
$result = $stmt->get_result();
$uploadRow = $result ? $result->fetch_assoc() : null;
if ($result instanceof mysqli_result) {
$result->free();
}
$stmt->close();
} else {
$uploadRow = null;
}

if (!is_array($uploadRow) || empty($uploadRow['url'])) {
notify('The selected image could not be found for this account.', 'ai-pics', 'danger');
} else {
$file = $_FILES['ai_upload_file'];
$uploadMime = '';
if ((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($file['tmp_name'])) {
notify('Upload failed. Please choose a JPG, JPEG, PNG, or WebP file and try again.', 'ai-pics', 'danger');
} elseif (($uploadMime = ai_pics_upload_image_mime($file['tmp_name'], (string) ($file['name'] ?? ''))) === '') {
notify('Only JPG, JPEG, PNG, and WebP image uploads are allowed for AI pictures.', 'ai-pics', 'warning');
} else {
$targetPath = ai_pics_target_disk_path((string) $uploadRow['url']);
if (ai_pics_convert_upload_to_webp($file['tmp_name'], $targetPath, $uploadMime, 90)) {
notify('AI picture uploaded successfully for <b>'.htmlentities((string) $uploadRow['url'], ENT_QUOTES, 'UTF-8').'</b> and converted to WebP. Existing AI image was replaced if present.', 'ai-pics', 'success');
} else {
notify('Failed to convert the uploaded image into WebP in the AI folder.', 'ai-pics', 'danger');
}
}
}
}
}

if ($albumId === '') {
notify('Open AI Pics from an album row to manage AI uploads for that album only.', 'ai-pics', 'warning');
} elseif (!is_array($albumRow) || empty($albumRow['id'])) {
notify('The selected album could not be found for this account.', 'ai-pics', 'danger');
}

$albumTitle = is_array($albumRow) ? trim((string) ($albumRow['title'] ?? '')) : '';
$albumDescr = is_array($albumRow) ? trim((string) ($albumRow['descr'] ?? '')) : '';
sadmin_title('<i class="fa fa-magic text-info"></i> AI Pics');

echo '<div class="col-lg-12 ai-pics-page">';

$rows = array();
if (is_array($albumRow) && !empty($albumRow['id'])) {
$scope = ai_pics_upload_scope_sql('u');
$sql = "SELECT `u`.`id`, `u`.`url`, `u`.`title`, `u`.`folder`, `u`.`time`, `u`.`uid`
FROM `".$prefix."uploads` `u`".$scope['sql']." AND `u`.`folder` = ?
ORDER BY `u`.`time` DESC";
if ($scope['sql'] === '') {
$sql = "SELECT `u`.`id`, `u`.`url`, `u`.`title`, `u`.`folder`, `u`.`time`, `u`.`uid`
FROM `".$prefix."uploads` `u`
WHERE `u`.`folder` = ?
ORDER BY `u`.`time` DESC";
}

$stmt = $con->prepare($sql);
if ($stmt) {
$values = $scope['values'];
$values[] = $albumId;
$bind = array($scope['types'].'s');
foreach ($values as $key => $value) {
$bind[] = &$values[$key];
}
call_user_func_array(array($stmt, 'bind_param'), $bind);
$stmt->execute();
$result = $stmt->get_result();
if ($result instanceof mysqli_result) {
while ($row = $result->fetch_assoc()) {
$rows[] = $row;
}
$result->free();
}
$stmt->close();
}
}

$aiCount = 0;
foreach ($rows as $row) {
if (file_exists(ai_pics_target_disk_path((string) $row['url']))) {
$aiCount++;
}
}
?>

<style>
.ai-pics-thumb {
width: 120px;
height: 120px;
object-fit: cover;
display: block;
background: #f4f4f4;
}

.ai-pics-status {
font-weight: bold;
display: inline-block;
padding: 4px 8px;
border-radius: 3px;
}

.ai-pics-status-ready {
background: #dff0d8;
color: #3c763d;
}

.ai-pics-status-missing {
background: #f2dede;
color: #a94442;
}

.ai-pics-upload-form input[type="file"] {
display: inline-block;
max-width: 240px;
}

.ai-pics-upload-form .btn {
margin-top: 6px;
}

.ai-pics-subtext {
color: #777;
font-size: 12px;
margin-top: 4px;
}

.ai-pics-page {
padding-bottom: 12px;
}

.ai-pics-notify .alert {
margin-bottom: 16px;
border-radius: 0;
box-shadow: none;
}

.ai-pics-notify .alert p {
margin: 0;
line-height: 1.45;
}

.ai-pics-notify .alert-success {
background: #eef7ea;
border: 1px solid #cfe2c6;
color: #2f5d2f;
}

.ai-pics-notify .alert-success .close {
color: #2f5d2f;
opacity: 0.7;
}

.ai-pics-header {
margin: 0 0 20px 0;
}

.ai-pics-header-meta {
background: #f8f8f8;
border: 1px solid #e6e6e6;
padding: 12px 14px;
display: flex;
align-items: flex-start;
justify-content: space-between;
gap: 15px;
flex-wrap: wrap;
}

.ai-pics-header-title {
font-size: 22px;
font-weight: 600;
line-height: 1.2;
margin: 0 0 4px 0;
}

.ai-pics-header-descr {
margin: 0;
color: #666;
}

.ai-pics-header-copy {
flex: 1 1 420px;
}

.ai-pics-header-actions {
flex: 0 0 auto;
align-self: flex-start;
}

.ai-pics-header-actions .btn {
white-space: nowrap;
}

@media (max-width: 767px) {
.ai-pics-header-actions {
width: 100%;
}

.ai-pics-header-actions .btn {
width: 100%;
}
}
</style>

<div class="ai-pics-notify"><?php echo $notify['ai-pics']; ?></div>

<div class="ai-pics-header">
<div class="ai-pics-header-meta">
<div class="ai-pics-header-copy">
<?php if ($albumTitle !== '') { ?>
<div class="ai-pics-header-title"><?php echo htmlentities($albumTitle, ENT_QUOTES, 'UTF-8'); ?></div>
<?php if ($albumDescr !== '') { ?>
<p class="ai-pics-header-descr"><?php echo htmlentities($albumDescr, ENT_QUOTES, 'UTF-8'); ?></p>
<?php } else { ?>
<p class="ai-pics-header-descr">Upload JPG, JPEG, PNG, or WebP and store AI WebP files for this album only.</p>
<?php } ?>
<?php } else { ?>
<div class="ai-pics-header-title">Select an album</div>
<p class="ai-pics-header-descr">Open AI Pics from an album row to manage AI WebP files for that album only.</p>
<?php } ?>
</div>
<div class="ai-pics-header-actions">
<a href="<?php echo $admin_url; ?>albums" class="btn btn-default btn-medium"><i class="fa fa-lg fa-fw fa-arrow-left"></i> Albums</a>
</div>
</div>

<div class="alert alert-info">
<p><b><?php echo count($rows); ?></b> images loaded from this album. <b><?php echo $aiCount; ?></b> AI WebP files currently exist in the <b>ai</b> folder for these images.</p>
<p>Each upload accepts <b>.jpg</b>, <b>.jpeg</b>, <b>.png</b>, or <b>.webp</b>. The image is converted to <b>.webp</b> at the same resolution with <b>90%</b> quality and stored in <b>ai/</b>. Existing AI files are overwritten.</p>
</div>

<table id="tbl-ai-pics" class="table table-striped table-bordered table-condensed table-hover display">
<thead>
<tr>
<th width="130">Preview</th>
<th width="130">AI Status</th>
<th width="240">File</th>
<th width="120">Uploaded</th>
<th>Upload / Replace AI WebP</th>
</tr>
</thead>
<tbody>
<?php
foreach ($rows as $row) {
$sourceFile = (string) $row['url'];
$thumbUrl = phpix_thumb_url($sourceFile);
$aiFile = ai_pics_target_filename($sourceFile);
$aiPath = ai_pics_target_disk_path($sourceFile);
$aiExists = file_exists($aiPath);
echo '<tr>';
echo '<td><img class="ai-pics-thumb" src="'.htmlentities($thumbUrl, ENT_QUOTES, 'UTF-8').'" alt=""></td>';
echo '<td data-sort="'.($aiExists ? '1' : '0').'">';
if ($aiExists) {
echo '<span class="ai-pics-status ai-pics-status-ready">Uploaded</span>';
echo '<div class="ai-pics-subtext">'.htmlentities($aiFile, ENT_QUOTES, 'UTF-8').'</div>';
} else {
echo '<span class="ai-pics-status ai-pics-status-missing">Missing</span>';
echo '<div class="ai-pics-subtext">'.htmlentities($aiFile, ENT_QUOTES, 'UTF-8').'</div>';
}
echo '</td>';
echo '<td><b>'.htmlentities($sourceFile, ENT_QUOTES, 'UTF-8').'</b><div class="ai-pics-subtext">'.htmlentities((string) ($row['title'] ?? ''), ENT_QUOTES, 'UTF-8').'</div></td>';
echo '<td data-sort="'.(int) $row['time'].'">'.xdate((int) $row['time'], "d-m-Y, h:i a", "both", '<br><i>', '</i>').'</td>';
echo '<td>';
echo '<form class="ai-pics-upload-form" method="post" enctype="multipart/form-data">';
echo '<input type="hidden" name="aid" value="'.htmlentities($albumId, ENT_QUOTES, 'UTF-8').'">';
echo '<input type="hidden" name="ai_upload_submit" value="1">';
echo '<input type="hidden" name="upload_id" value="'.htmlentities((string) $row['id'], ENT_QUOTES, 'UTF-8').'">';
echo '<input class="ai-pics-upload-input" type="file" name="ai_upload_file" accept=\".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp\" required>';
if ($aiExists) {
echo '<div><button type="submit" class="btn btn-sm btn-warning">Replace AI WebP</button></div>';
}
echo '</form>';
echo '</td>';
echo '</tr>';
}
?>
</tbody>
</table>

</div>

<script>
$(document).ready(function() {
$('#tbl-ai-pics').DataTable({
responsive: true,
pageLength: 25,
order: [[1, 'asc'], [3, 'desc']]
});

$('.ai-pics-upload-input').on('change', function() {
var input = this;
if(!input.files || input.files.length !== 1){
return;
}
var form = $(input).closest('form');
if(form.data('uploading')==='1'){
return;
}
form.data('uploading', '1');
var button = form.find('button[type="submit"]');
button.text('Uploading...');
var formEl = form.get(0);
if(formEl && typeof formEl.requestSubmit === 'function'){
formEl.requestSubmit();
} else {
formEl.submit();
}
});
});
</script>
