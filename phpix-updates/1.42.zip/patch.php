<?php 

include('../../phpix-config.php'); 

mysqli_query($con, "ALTER TABLE `".$prefix."access` ADD `type` VARCHAR(20) NOT NULL DEFAULT 'album' AFTER `uid`;");
mysqli_query($con, "ALTER TABLE `".$prefix."uploads` ADD `access` VARCHAR(20) NOT NULL DEFAULT 'public' AFTER `type`;");

mysqli_close($con);
 ?>