<?php 

include('../../phpix-config.php'); 

mysqli_query($con, "ALTER TABLE `".$prefix."albums` ADD `uid` VARCHAR(100) NOT NULL DEFAULT '1' AFTER `parent`;");

mysqli_query($con, "ALTER TABLE `".$prefix."users` ADD `name` VARCHAR(50) NOT NULL DEFAULT 'no_name' AFTER `id`;");

mysqli_close($con);

 ?>