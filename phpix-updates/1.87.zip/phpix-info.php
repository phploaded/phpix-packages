<?php 

$software_version = '1.87';
$software_date = '1603041199'; /* Sunday, 18-10-2020, 07:13:19 pm */
$software_updated = '1732388235'; /* Saturday, 23-11-2024, 07:57:15 pm */
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

?>