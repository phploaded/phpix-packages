<?php 

include('../../phpix-config.php'); 

mkdir('../../phpix-imports/packages/');

mysqli_query($con, "CREATE TABLE `".$prefix."packages` (
  `id` int(11) NOT NULL,
  `dir` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

mysqli_query($con, "ALTER TABLE `".$prefix."packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dir` (`dir`);");

mysqli_query($con, "ALTER TABLE `".$prefix."packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;");

mysqli_close($con);

 ?>