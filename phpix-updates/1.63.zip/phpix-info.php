<?php 

$software_version = '1.63';
$software_date = '1603041199';
$software_updated = '1603364159';
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

 ?>