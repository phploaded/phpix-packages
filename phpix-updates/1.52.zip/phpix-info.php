<?php 

$software_version = '1.52';
$software_date = '1599748208';
$software_updated = '1602951602';
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

 ?>