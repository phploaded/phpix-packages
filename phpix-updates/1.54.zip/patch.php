<?php 

include('../../phpix-config.php'); 

mysqli_query($con, "CREATE TABLE `".$prefix."dirs` (
  `id` varchar(20) NOT NULL,
  `sort` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `files` int(11) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

mysqli_query($con, "INSERT INTO `".$prefix."dirs` (`id`, `sort`, `time`, `files`, `size`) VALUES
('cover', 0, 1603039527, 5, 774328),
('fhd', 2, 1603039513, 52, 20694233),
('full', 1, 1603039523, 45, 72761035),
('hd', 3, 1603039477, 52, 9683781),
('qhd', 4, 1603039465, 52, 4634330),
('thumb', 5, 1603039414, 52, 685168);");

mysqli_query($con, "ALTER TABLE `".$prefix."dirs`
  ADD PRIMARY KEY (`id`);");

mysqli_close($con);

 ?>