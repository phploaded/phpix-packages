<?php 

if($_GET['method']=='nocache'){
@unlink('cache/'.$_GET['file']);
echo "<script>document.location.href = '".$domain."phpix-manage.php?page=index';</script>";
}



if($_GET['method']=='calculate'){

$filenm = $_SERVER['HTTP_HOST'].'-index-'.date("Ym").'.html';
@unlink('cache/'.$filenm);

$path = $_GET['dir'];
$files = array_diff(scandir($path), array('.', '..'));

$bytes = 0;
foreach($files as $file){
$bytes = $bytes + filesize($path.'/'.$file);
}

mysqli_query($con, "UPDATE `".$prefix."dirs` SET `time`='".time()."', `files`='".count($files)."', `size`='$bytes' WHERE `id`='".$path."'");
echo "<script>document.location.href = '".$domain."phpix-manage.php?page=index';</script>";
}





if($_GET['method']=='generate'){

if($_GET['dir']=='thumb'){
$dir = 'full';
} else {
$dir = $_GET['dir'];
}

echo'<br><br><ol class="gen-files">';
$data = mysqli_query($con, "SELECT `thumb` FROM `".$prefix."uploads`");
while($row = mysqli_fetch_assoc($data)){
echo'<li>'.$row['thumb'].'</li>';
}
echo"</ol>
<script>
var quality = '".$dir."';
$(document).ready(function(){
start_generating();
});

\r\n
function start_generating(){
if($('.gen-files li').length!=0){
$.post(main_domain+'thumb-gen.php', {id:$('.gen-files li:last-child').html(), q:quality} ,function(){
$('.gen-files li:last-child').remove();
start_generating();
});
} else {
document.location.href = '".$domain."phpix-manage.php?page=operations&method=calculate&dir=".$_GET['dir']."';
}
}
</script>";


}




if($_GET['method']=='delete'){

$filenm = $_SERVER['HTTP_HOST'].'-index-'.date("Ym").'.html';
@unlink('cache/'.$filenm);

$path = $_GET['dir'];
if($path!='full'){
$files = array_diff(scandir($path), array('.', '..'));

foreach($files as $file){
unlink($path.'/'.$file);
}

mysqli_query($con, "UPDATE `".$prefix."dirs` SET `time`='".time()."', `files`='0', `size`='0' WHERE `id`='".$path."'");
echo "<script>document.location.href = '".$domain."phpix-manage.php?page=index';</script>";
} else {
echo'<br><br><br><br>Cannot delete original images!';
}
}

 ?>