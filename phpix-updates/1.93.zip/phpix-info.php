<?php 

$software_version = '1.93';
$software_date = '1603041199'; /* Sunday, 18-10-2020, 07:13:19 pm */
$software_updated = '1733497772'; /* Friday, 06-12-2024, 04:09:32 pm */
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

?>