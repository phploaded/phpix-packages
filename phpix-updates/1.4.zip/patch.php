<?php 

include('../../phpix-config.php'); 

mysqli_query($con, "ALTER TABLE `".$prefix."albums` ADD `parent` VARCHAR(20) NOT NULL AFTER `count`;");

mysqli_close($con);
 ?>