<?php 
include('phpix-config.php');

$data = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM `".$prefix."uploads` WHERE `url`='".$_GET['u']."' limit 1"));

$url = $gallery_domain.'full/'.$_GET['u'];

$qhd = $gallery_domain.'qhd/'.$_GET['u'];

echo'<!DOCTYPE html>
<html>
<head><meta property="og:title" content="'.$data['title'].'" />
<meta property="og:url" content="'.$url.'" />
<meta property="og:description" content="'.$data['caption'].'">
<meta property="og:image" content="'.$qhd.'">
</head><body>
<script>document.location.href="'.$gallery_domain.'phpix-album.php?aid='.$data['folder'].'&pic='.$_GET['u'].'";</script>
</body>
';
mysqli_close($con);
?>