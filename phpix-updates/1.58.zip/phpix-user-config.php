<?php 

$default_admin_theme = 'paper.bootstrap.min';
$default_admin_menu = 'inverse';

 ?>