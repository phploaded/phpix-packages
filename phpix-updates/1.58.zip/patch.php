<?php 

include('../../phpix-config.php'); 

include('../../phpix-admin-functions.php'); 

rrmdir('../../phpix-libs/theme/');


 ?>