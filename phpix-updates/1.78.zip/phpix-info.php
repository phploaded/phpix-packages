<?php 

$software_version = '1.78';
$software_date = '1603041199'; /* Sunday, 18-10-2020, 07:13:19 pm */
$software_updated = '1731604211'; /* Thursday, 14-11-2024, 06:10:11 pm */
$software_jsonURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/updates.json';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/phpix-packages/main/phpix-updates/';

?>