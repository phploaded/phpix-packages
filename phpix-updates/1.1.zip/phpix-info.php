<?php 

$software_version = '1.1';
$software_date = '1599748208';
$software_updated = '1599748208';
$software_jsonURL = 'http://phploaded.com/updates/updates.php';
$software_zipURL = 'https://raw.githubusercontent.com/phploaded/PHPix/master/updates/';

 ?>