<?php 

$aid = htmlentities($_GET['aid']);
$al = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM `".$prefix."albums` WHERE `id`='$aid'"));

sadmin_title('Backup <small>'.$al['title'].'</small>'); 


$txtFile = 'temp/'.$aid.'_'.$al['slug'].'.json';
if(file_exists($txtFile)){
$tdata = json_decode(file_get_contents($txtFile), TRUE);
}

$zipFile = 'temp/'.$aid.'_'.$al['slug'].'.zip';
if(file_exists($zipFile) && ($tdata['AlbumTimestamp'] == $al['updated']) && ($tdata['AlbumFiles'] == $al['count'])){
echo'<br>There was no change in the album since last backup file was created. Old zip file is being loaded for download.<br>';
} else { 

if(file_exists($zipFile)){unlink($zipFile);}
if(file_exists($txtFile)){unlink($txtFile);}

$zip = new ZipArchive;
if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE)
{

$res = mysqli_query($con, "SELECT * FROM `".$prefix."uploads` WHERE `folder`='$aid'");

$nfiles = 0;
$osize = 0;
while($row = mysqli_fetch_assoc($res)){
if(file_exists('full/'.$row['url'])){
// Add file to zip and rename it for removing folder path
$zip->addFile('full/'.$row['url'], $row['url']);
++$nfiles;
$osize = $osize + $row['size'];
}
}

    // All files are added, so close the zip file.
    $zip->close();
	echo'<br>New backup created successfully.<br>';
	
// make json file
$myfile = fopen($txtFile, "w") or die("Unable to create json info file!");
$info['ZippedFiles'] = $nfiles;
$info['OriginalSize'] = $osize;
$info['ZippedSize'] = filesize($zipFile);
$info['CreatedTimestamp'] = time();
$info['AlbumTimestamp'] = $al['updated'];
$info['AlbumFiles'] = $al['count'];
$txt = json_encode($info);
fwrite($myfile, $txt);
fclose($myfile);

// recreating tdata with new file data
$tdata = json_decode(file_get_contents($txtFile), TRUE);
}
}

$tfile = 'cover/'.$al['thumb'];

if($al['thumb']!='' && file_exists($tfile)){
$thumb = $domain.''.$tfile;
} else {
$thumb = $domain.'phpix-libs/images/holder.svg';
}

echo'<br><br><div class="panel panel-info">
  <div class="panel-heading">Backup Information</div>
  <div class="panel-body">
	  <div class="col-xs-12 col-sm-6 col-md-3"><img class="img-thumbnail" src="'.$thumb.'" /></div>
	  <div class="col-xs-12 col-sm-6 col-md-9">
		  <ul>
			<li>Images in zip file : '.$tdata['ZippedFiles'].'</li>
			<li>Original data size : '.xsize($tdata['OriginalSize']).'</li>
			<li>Zipped file size : '.xsize($tdata['ZippedSize']).'</li>
			<li>Created On : '.xdate($tdata['CreatedTimestamp']).'</li>
		  </ul>
	  </div>
  </div>

<div class="panel-footer">
<a class="btn btn-success pull-right" download target="_blank" href="'.$domain.''.$zipFile.'">Download Backup</a>
<div class="clearfix"></div>
</div>

</div>';




?>