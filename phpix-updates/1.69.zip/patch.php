<?php 

include('../../phpix-config.php'); 

mysqli_query($con, "INSERT INTO `".$prefix."dirs` (`id`, `sort`, `time`, `files`, `size`) VALUES ('temp', '6', '0', '0', '0');");

mysqli_close($con);
 ?>